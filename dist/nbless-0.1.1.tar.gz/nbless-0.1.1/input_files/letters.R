letters[1:26]
LETTERS[1:26]
